/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.user.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import kr.ac.kku.cs.wp.chuh00.support.sql.ConnectionPoolUtil;
import kr.ac.kku.cs.wp.chuh00.support.sql.UserDAO;
import kr.ac.kku.cs.wp.chuh00.support.sql.UserDAOHiberanteImpl;
import kr.ac.kku.cs.wp.chuh00.user.entity.User;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class UserServiceImple implements UserService {
	private static final Logger logger = LogManager.getLogger(UserServiceImple.class);
	private UserDAO dao = new UserDAOHiberanteImpl(); // DAO 구현체 초기화
	private static final String DB_URL = "jdbc:mysql://localhost:3306/webapp_JIN"; // 데이터베이스 이름으로 업데이트
	private static final String USER = "JIN"; // 데이터베이스 사용자 이름으로 업데이트
	private static final String PASSWORD = "202221889"; // 데이터베이스 비밀번호로 업데이트

	public Connection getConnection() throws SQLException {
		String url = "jdbc:mysql://localhost:3306/webapp_JIN"; // 데이터베이스 이름
		String user = "JIN"; // 사용자 이름
		String password = "202221889"; // 사용자 비밀번호
		return DriverManager.getConnection(url, user, password);
	}

	@Override
	public List<User> getUsers(User paramUser) {
		List<User> users = new ArrayList<>();
		String sql = "SELECT * FROM users"; // 실제 쿼리로 교체

		try (Connection conn = ConnectionPoolUtil.getConnection(); // HikariCP에서 커넥션 가져오기
				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery()) {

			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id")); // 사용자 필드로 업데이트
				user.setName(rs.getString("name"));
				// 필요한 추가 필드 추가
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}

	@Override
	public User getUserById(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteUser(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void createUser(User user) {
		// TODO Auto-generated method stub

	}

}
