/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.user.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.ac.kku.cs.wp.chuh00.user.controller.User;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class UserData {
	private static UserData THIS;
	private Map<String, User> users;

	private UserData() {
		this.initData();
	}

	private void initData() {
		users = new HashMap<>();

		String[] sNames = { "관리자", "안창호", "안중근", "유관순", "홍범도", "김좌진", "남자현", "윤봉길", "이봉창", "김원봉" };

		String[] sEmails = { "kim1@kku.ac.kr", "an1@kku.ac.kr", "an2@kku.ac.kr", "yu@kku.ac.kr", "hong@kku.ac.kr",
				"kim2@kku.ac.kr", "nam@kku.ac.kr", "yun1@kku.ac.kr", "lee@kku.ac.kr", "kim3@kku.ac.kr" };

		String[] sRoles = { "관리자", "개발자", "시스템관리자" };

		for (int i = 0; i < 20; i++) {
			User user = new User();
			user.setPhotoSRC("https://via.placeholder.com/150");
			user.setName(sNames[(i % sNames.length)]);
			user.setEmail(sEmails[(i % sEmails.length)]);
			user.setId("kku_" + (1000 + i));

			user.setPassword("password");

			List<String> roles = new ArrayList<>();
			roles.add(sRoles[(i % sRoles.length)]);
			roles.add(sRoles[(i + 1) % sRoles.length]);
			user.setRoles(roles);
			user.setStatus("재직");

			users.put(user.getId(), user);
		}
	}

	public Map<String, User> getData() {
		return users;
	}

	public static synchronized UserData getInstance() {
		if (THIS == null) {
			THIS = new UserData();
		}
		return THIS;
	}

	public List<User> getUsers() {
		return null;
	}

}
