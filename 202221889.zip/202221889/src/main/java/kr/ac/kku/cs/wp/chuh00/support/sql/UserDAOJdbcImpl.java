/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.support.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import kr.ac.kku.cs.wp.chuh00.support.sql.ConnectionPoolUtil;
import kr.ac.kku.cs.wp.chuh00.user.entity.Role;
import kr.ac.kku.cs.wp.chuh00.user.entity.User;
import kr.ac.kku.cs.wp.chuh00.user.entity.UserRole;
import kr.ac.kku.cs.wp.chuh00.user.entity.UserRoleId;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public abstract class UserDAOJdbcImpl implements UserDAO {
    private static final Logger logger = LogManager.getLogger(UserDAOJdbcImpl.class);

    private final String querySelectById = "select * from user where id= ?";
    private final String querySelectUserRole = "select * from user_role where user_id = ?";
    private final String querySelectList = "select * from user ";

    @Override
    public User getUserById(String userId) {
        User user = new User();
        try (Connection conn = ConnectionPoolUtil.getConnection()) {
            PreparedStatement pstmt = conn.prepareStatement(querySelectById);
            PreparedStatement sPstmt = conn.prepareStatement(querySelectUserRole);
            pstmt.setString(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                user.setId(rs.getString(1));
                user.setName(rs.getString(2));
                user.setEmail(rs.getString(3));
                user.setPassword(rs.getString(4));
                user.setStatus(rs.getString(5));
                
                sPstmt.setString(1, user.getId());
                ResultSet rsur = sPstmt.executeQuery();
                List<UserRole> urList = new ArrayList<>();
                while (rsur.next()) {
                    Role role = new Role();  // Role 클래스가 필요
                    role.setId(rsur.getString(2));
                    role.setRole(rsur.getString(3));
                    
                    UserRoleId uri = new UserRoleId();
                    uri.setRoleId(role.getId());
                    uri.setUserId(user.getId());
                    
                    UserRole ur = new UserRole();
                    ur.setUser(user);
                    ur.setRole(role);
                    ur.setId(uri);
                    
                    urList.add(ur);
                }
                rsur.close();
                user.setUserRoles(urList);
            }
            rs.close();
            sPstmt.close();
            pstmt.close();
        } catch (SQLException e) {
            logger.error("Error fetching user by ID", e);
            e.printStackTrace();
        }
        return user;
    }
    @Override  
    public List<User> getUsers(User pUser) {  
        List<User> users = new ArrayList<User>();  // 올바른 ArrayList 선언
        try (Connection conn = ConnectionPoolUtil.getConnection()) {  
            PreparedStatement pstmt = conn.prepareStatement(querySelectList);  
            PreparedStatement sPstmt = conn.prepareStatement(querySelectUserRole);  
            ResultSet rs = pstmt.executeQuery();  // 유저 목록 조회
            
            while (rs.next()) {  
                User user = new User();  // User 객체 생성
                user.setId(rs.getString(1));  
                user.setName(rs.getString(2));  
                user.setEmail(rs.getString(3));  
                user.setPassword(rs.getString(4));  
                user.setStatus(rs.getString(5));  

                sPstmt.setString(1, user.getId());  // 유저 아이디에 따른 역할 조회
                ResultSet rsur = sPstmt.executeQuery();  
                List<UserRole> urList = new ArrayList<UserRole>();  // 역할 리스트 생성
                
                while (rsur.next()) {  
                    Role role = new Role();  // Role 객체 생성
                    role.setId(rsur.getString(2));  
                    role.setRole(rsur.getString(3));  
                    
                    UserRoleId uri = new UserRoleId();  // UserRoleId 객체 생성
                    uri.setRoleId(role.getId());  
                    uri.setUserId(user.getId());  

                    UserRole ur = new UserRole();  // UserRole 객체 생성
                    ur.setUser(user);  
                    ur.setRole(role);  
                    ur.setId(uri);  
                    urList.add(ur);  // 역할 리스트에 추가
                }  
                rsur.close();  // ResultSet 닫기
                user.setUserRoles(urList);  // 유저에 역할 리스트 설정
                users.add(user);  // 유저 리스트에 추가
            }  
            rs.close();  // ResultSet 닫기
            sPstmt.close();  // PreparedStatement 닫기
            pstmt.close();  // PreparedStatement 닫기
        } catch (SQLException e) {  
            e.printStackTrace();  // 예외 발생 시 스택 트레이스 출력
        }  
        return users;  // 유저 리스트 반환
    }
}