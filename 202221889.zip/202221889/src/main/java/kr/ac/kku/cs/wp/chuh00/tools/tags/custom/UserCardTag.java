/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.tools.tags.custom;

import java.io.IOException;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.SimpleTagSupport;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class UserCardTag extends SimpleTagSupport {

	private String name = null;
	private String email = null;
	private String id = null;
	private String roles = null;
	private String status = null;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public void doTag() throws JspException, IOException {
		// TODO Auto-generated method stub
		super.doTag();

		String userCard = "<div class=\"user-card\" data-name=\"" + name + "\" data-email=\"" + email
				+ "\" data-role=\"" + roles + "\" data-id=\"" + id + "\">\n"
				+ "    <img src=\"https://via.placeholder.com/150\" alt=\"" + name + " 사진\">\n"
				+ "    <div class=\"user-info\">\n" + "        <h3>" + name + "</h3>\n"
				+ "        <p><strong>이메일:</strong> " + email + "</p>\n" + "        <p><strong>역할:</strong> " + roles
				+ "</p>\n" + "        <p><strong>사번:</strong> " + id + "</p>\n" + "        <p><strong>상태:</strong> "
				+ status + "</p>\n" + "        <button onclick=\"alert('" + name + "의 상세 정보')\">상세 보기</button>\n"
				+ "    </div>\n" + "</div>";

		getJspContext().getOut().print(userCard);

	}

}
