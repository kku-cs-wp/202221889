/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.support.sql;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import kr.ac.kku.cs.wp.chuh00.support.sql.MybatisUtil;
import kr.ac.kku.cs.wp.chuh00.user.entity.Role;
import kr.ac.kku.cs.wp.chuh00.user.entity.User;
import kr.ac.kku.cs.wp.chuh00.user.entity.UserRole;
import kr.ac.kku.cs.wp.chuh00.user.entity.UserRoleId;
import kr.ac.kku.cs.wp.chuh00.user.mapper.UserMapper;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class UserDAOMybatisImpl implements UserDAO{
	private static final Logger logger=LogManager.getLogger(UserDAOMybatisImpl.class);

	@Override
	public User getUserById(String userId) {
	    User user = null;
	    SqlSessionFactory sqlSessionFactory = MybatisUtil.getSqlSessionFactory();  // SqlSessionFactory 인스턴스 생성
	    
	    try (SqlSession session = sqlSessionFactory.openSession()) {  // try-with-resources를 사용해 SqlSession 열기
	        UserMapper mapper = session.getMapper(UserMapper.class);  // Mapper 가져오기
	        user = mapper.getUserById(userId);  // User ID로 사용자 가져오기
	        
	        // User의 역할 가져오기
	        List<Map> userRoles = mapper.getUserRole(user.getId());
	        List<UserRole> urList = new ArrayList<UserRole>();  // 역할 리스트 생성
	        
	        for (Map userRole : userRoles) {
	            Role role = new Role();  // 역할 객체 생성
	            role.setId((String) userRole.get("roleId"));  // 역할 ID 설정
	            role.setRole((String) userRole.get("role"));  // 역할 이름 설정
	            
	            UserRoleId uri = new UserRoleId();  // UserRoleId 객체 생성
	            uri.setRoleId(role.getId());  // 역할 ID 설정
	            uri.setUserId(user.getId());  // 사용자 ID 설정
	            
	            UserRole ur = new UserRole();  // UserRole 객체 생성
	            ur.setUser(user);  // User 설정
	            ur.setRole(role);  // Role 설정
	            ur.setId(uri);  // UserRoleId 설정
	            
	            urList.add(ur);  // 역할 리스트에 추가
	        }
	        
	        user.setUserRoles(urList);  // User에 역할 리스트 설정
	    } catch (Exception e) {
	        e.printStackTrace();  // 예외 발생 시 스택 트레이스 출력
	    }
	    
	    return user;  // User 반환
	}

	@Override
	public User getUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteUser(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> getUsers(User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
