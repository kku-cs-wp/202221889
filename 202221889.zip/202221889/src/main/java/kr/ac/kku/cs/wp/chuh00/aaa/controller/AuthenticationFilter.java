/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.aaa.controller;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import kr.ac.kku.cs.wp.chuh00.support.servlet.BaseFilter;
import kr.ac.kku.cs.wp.chuh00.user.controller.User;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class AuthenticationFilter extends BaseFilter {
	private boolean valve = true;

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		super.init(filterConfig);
		String sValve = filterConfig.getInitParameter("valve");

		if (sValve != null) {
			if (sValve.equals("on")) {
				valve = true;
			} else if (sValve.equals("off")) {
				valve = false;
			}
		}
		log("init AuthenticationFilter (" + sValve + ")");
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// 로그인 인증 로직 구현
		if (valve) {
			HttpServletRequest req = (HttpServletRequest) request;
			HttpSession hs = req.getSession();
			Object userObject = hs.getAttribute("user");

			// 객체 타입 확인 및 적절한 처리
			if (userObject instanceof User) {
				User user = (User) userObject;
				log(user.getId() + " has logged in");
				chain.doFilter(request, response);
			} else if (userObject instanceof Account) {
				Account account = (Account) userObject;
				log(account.getId() + " has logged in (Account)");
				chain.doFilter(request, response);
			} else {
				HttpServletResponse res = (HttpServletResponse) response;
				res.getWriter().println("Please log in");
			}
		} else {
			chain.doFilter(request, response);
		}
	}

}