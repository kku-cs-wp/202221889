/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.support.sql;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class HibernateUtil {

    // Stack 영역에서 Hibernate 설정 로딩 SessionFactory 생성
    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
            // Hibernate 설정 파일을 로딩하여 SessionFactory를 빌드함
            return new Configuration().configure().buildSessionFactory();
        } catch (Throwable ex) {
            // 초기화 오류 발생 시 예외 처리
            throw new ExceptionInInitializerError(ex);
        }
    }

    // SessionFactory 반환 메서드
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    // SessionFactory 종료 메서드
    public static void shutdown() {
        // SessionFactory 자원 해제
        getSessionFactory().close();
    }
}