/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.aaa.controller;

import java.io.IOException;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import kr.ac.kku.cs.wp.chuh00.user.controller.User;
import kr.ac.kku.cs.wp.chuh00.user.controller.UserData;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

@WebServlet(urlPatterns = { "/login", "/logout" })

public class LoginControllerServlet extends HttpServlet {
	private static final Logger logger = LogManager.getLogger(LoginControllerServlet.class);
	private static final long serialVersionUID = 1L;

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// super.doGet(req, resp);

		String context = req.getServletContext().getContextPath();
		String uriStr = req.getRequestURI().replaceAll(context, "");
		log("in service :" + uriStr);
		if (uriStr.equals("/login")) {
			req.getRequestDispatcher("/WEB-INF/view/auth/login.jsp").forward(req, resp);

		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String context = req.getServletContext().getContextPath();
		String uriStr = req.getRequestURI().replaceAll(context, "");

		if (uriStr.equals("/login")) {
			Map<String, User> users = UserData.getInstance().getData();
			String id = req.getParameter("username");
			String password = req.getParameter("password");
			User user = users.get(id);

			if (user == null || !password.equals(user.getPassword())) {
				req.getSession().setAttribute("error", "Invalid username or password.");
				resp.sendRedirect(context + "/login");
			} else {
				HttpSession session = req.getSession();
				Account ac = new Account();
				ac.setId(id);
				ac.setName(user.getName());
				ac.setRoles(user.getRoles());
				ac.setEmail(user.getEmail());
				session.setAttribute("user", ac);

				logger.info("Redirecting to: " + context + "/jsp/index.jsp");
				resp.sendRedirect(context + "/jsp/index.jsp");
			}
		} else if (uriStr.equals("/logout")) {
			HttpSession session = req.getSession();
			if (session != null) {
				session.invalidate();
			}
			resp.sendRedirect(context + "/login");
		}
	}
}