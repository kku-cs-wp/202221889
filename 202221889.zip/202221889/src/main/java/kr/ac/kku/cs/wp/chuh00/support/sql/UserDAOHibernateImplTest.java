/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.support.sql;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;

import kr.ac.kku.cs.wp.chuh00.tools.message.MessageException;
import kr.ac.kku.cs.wp.chuh00.user.entity.User;
import kr.ac.kku.cs.wp.chuh00.user.entity.UserRole;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class UserDAOHibernateImplTest {
    private static final Logger logger = LogManager.getLogger(UserDAOHibernateImplTest.class);

    @Test
    void testGetUser() {
        UserDAO dao = new UserDAOHiberanteImpl();  // UserDAO의 구현체 인스턴스 생성
        String userId = "kku_1001";  // 테스트할 User ID
        User user = dao.getUserById(userId);  // User 객체 가져오기
        
        // assertEquals로 ID가 일치하는지 확인
        assertEquals(userId, user.getId());

        // UserRole 리스트 가져오기
        List<UserRole> userRoles = user.getUserRoles();
        for (UserRole userRole : userRoles) {
            logger.debug("userid {}, roleid {}", userRole.getUser().getId(), userRole.getRole().getRole());
        }

        // User의 이름을 로그로 출력
        logger.debug(user.getName());
    }

    @Test
    void testGetUsers() {
        UserDAO dao = new UserDAOHiberanteImpl();  // UserDAO의 구현체 인스턴스 생성
        User user = null;  // null로 설정하여 모든 사용자 가져오기
        List<User> users = dao.getUsers(user);  // User 목록 가져오기

        // users 리스트의 크기를 로그로 출력
        logger.debug(users.size());

        // null이 아닌지 확인
        assertNotNull(users);
    }
    @Test
    void testCreateUserUpdateDelete() {
        UserDAO dao = new UserDAOHiberanteImpl();  // UserDAO의 구현체 인스턴스 생성
        User user = new User();  // User 객체 생성

        // 사용자의 이메일과 상태 설정
        user.setEmail("test_1@kku.ac.kr");
        user.setStatus("재직중");
        
        Date now = new Date();  // 현재 시간 설정
        user.setCreatedAt(now);
        user.setUpdatedAt(now);
        
        User createdUser = null;

        // 사용자 이름이 null일 때 예외 발생 확인
        Exception exception = assertThrows(MessageException.class, () -> {
            dao.createUser(user);
        });
        logger.debug(exception.getMessage());
        assertEquals("not-null property references a null or transient value: kr.ac.kku.cs.wp.chuh00.user.entity.User.name", exception.getMessage());

        // 사용자 이름 설정 후 사용자 생성
        user.setName("홍길동");
        createdUser = dao.createUser(user);
        assertNotNull(createdUser);
        logger.debug("created user {}, id {}", createdUser.getName(), createdUser.getId());

        // 사용자 이름 업데이트
        createdUser.setName("심청이");
        User updatedUser = dao.updateUser(createdUser);
        assertEquals(updatedUser.getId(), createdUser.getId());  // ID 비교로 업데이트 확인
        logger.debug("updated username {}, id {}", updatedUser.getName(), updatedUser.getId());

        // 사용자 삭제
        dao.deleteUser(updatedUser);
    }
    
}
