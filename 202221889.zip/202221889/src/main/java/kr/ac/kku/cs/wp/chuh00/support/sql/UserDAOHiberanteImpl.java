/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.support.sql;

import java.util.ArrayList;  
import java.util.List;  
import jakarta.persistence.criteria.CriteriaBuilder;  
import jakarta.persistence.criteria.CriteriaQuery; 
import jakarta.persistence.criteria.Join;  
import jakarta.persistence.criteria.JoinType;  
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.hibernate.HibernateException;  
import org.hibernate.Session; 
import org.hibernate.Transaction; 
import kr.ac.kku.cs.wp.chuh00.support.sql.HibernateUtil;  
import kr.ac.kku.cs.wp.chuh00.tools.message.MessageException;  
import kr.ac.kku.cs.wp.chuh00.user.entity.User;  
import kr.ac.kku.cs.wp.chuh00.user.entity.UserRole;
import jakarta.persistence.TypedQuery;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class UserDAOHiberanteImpl implements UserDAO {

    @Override
    public User getUserById(String userId) {
        User user = null;  // User 객체 초기화

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {  // Hibernate 세션 열기
            user = session.get(User.class, userId);  // userId로 User 객체 가져오기
        } catch (HibernateException e) {  // Hibernate 예외 처리
            e.printStackTrace();  // 예외 발생 시 스택 트레이스 출력
        }

        return user;  // User 객체 반환
    }

    @Override
    public User getUser(User user) throws MessageException { // 예외 처리 추가
        Transaction tx = null;  // Transaction 객체 초기화
        Session session = null;  // Session 객체 초기화

        if (user != null) {  // user가 null이 아닌 경우
            try {
                session = HibernateUtil.getSessionFactory().openSession();  // Hibernate 세션 열기
                tx = session.beginTransaction();  // 트랜잭션 시작
                user = session.get(User.class, user.getId());  // ID로 User 객체 가져오기
                tx.commit();  // 트랜잭션 커밋
            } catch (HibernateException e) {  // Hibernate 예외 처리
                e.printStackTrace();  // 예외 발생 시 스택 트레이스 출력
                if (tx != null && tx.isActive()) {  // 트랜잭션이 활성화된 경우
                    tx.rollback();  // 트랜잭션 롤백
                }
                throw new MessageException(e.getMessage(), e);  // 사용자 정의 예외 던지기
            } finally {
                if (session != null && session.isOpen()) {  // 세션이 열려 있는 경우
                    session.close();  // 세션 닫기
                }
            }
        }

        return user;  // User 객체 반환
    }

    @Override
    public User updateUser(User user) {
        Session session = null;  // Session 객체 초기화
        Transaction tx = null;  // Transaction 객체 초기화

        try {
            session = HibernateUtil.getSessionFactory().openSession();  // Hibernate 세션 열기
            tx = session.beginTransaction();  // 트랜잭션 시작

            // 기존 사용자 정보 가져오기
            User existingUser = session.get(User.class, user.getId());

            // 기존 사용자와 병합하여 업데이트
            if (existingUser != null) {
                user = (User) session.merge(user);  // user 객체를 병합
            }

            tx.commit();  // 트랜잭션 커밋
        } catch (HibernateException e) {  // Hibernate 예외 처리
            e.printStackTrace();  // 예외 발생 시 스택 트레이스 출력
            if (tx != null && tx.isActive()) {  // 트랜잭션이 활성화된 경우
                tx.rollback();  // 트랜잭션 롤백
            }
            throw new MessageException(e.getMessage(), e);  // 사용자 정의 예외 던지기
        } finally {
            if (session != null && session.isOpen()) {  // 세션이 열려 있는 경우
                session.close();  // 세션 닫기
            }
        }

        return user;  // 업데이트된 User 객체 반환
    }

    @Override
    public void deleteUser(User user) {
        Session session = null;  // Session 객체 초기화
        Transaction tx = null;  // Transaction 객체 초기화

        try {
            session = HibernateUtil.getSessionFactory().openSession();  // Hibernate 세션 열기
            tx = session.beginTransaction();  // 트랜잭션 시작

            // 사용자가 null이 아닌 경우에만 삭제 시도
            if (user != null) {
                user = session.get(User.class, user.getId());  // User를 세션에서 가져오기
                if (user != null) {
                    session.remove(user);  // User 삭제
                } else {
                    throw new MessageException("User not found for deletion with id: " + user.getId());
                }
            }
            
            tx.commit();  // 트랜잭션 커밋
        } catch (HibernateException e) {  // Hibernate 예외 처리
            if (tx != null && tx.isActive()) {  // 트랜잭션이 활성화된 경우
                tx.rollback();  // 트랜잭션 롤백
            }
            throw new MessageException(e.getMessage(), e);  // 사용자 정의 예외 던지기
        } finally {
            if (session != null && session.isOpen()) {  // 세션이 열려 있는 경우
                session.close();  // 세션 닫기
            }
        }
    }

    @Override
    public User createUser(User user) {
        User rtn = null;  // 반환할 User 객체 초기화
        Session session = null;  // Session 객체 초기화
        Transaction tx = null;  // Transaction 객체 초기화

        try {
            session = HibernateUtil.getSessionFactory().openSession();  // Hibernate 세션 열기
            tx = session.beginTransaction();  // 트랜잭션 시작
            
            String newId = generateNewId(session);  // 새로운 ID 생성
            user.setId(newId);  // User에 새로운 ID 설정
            user.setPassword(newId);  // User에 비밀번호 설정 (비밀번호는 별도로 안전하게 처리하는 것이 좋습니다)
            
            session.persist(user);  // User 객체 저장
            tx.commit();  // 트랜잭션 커밋
            
            // 새로 생성된 User 객체를 가져오기
            rtn = session.get(User.class, user.getId());
        } catch (HibernateException e) {  // Hibernate 예외 처리
            if (tx != null && tx.isActive()) {  // 트랜잭션이 활성화된 경우
                tx.rollback();  // 트랜잭션 롤백
            }
            throw new MessageException(e.getMessage(), e);  // 사용자 정의 예외 던지기
        } finally {
            if (session != null && session.isOpen()) {  // 세션이 열려 있는 경우
                session.close();  // 세션 닫기
            }
        }
        return rtn;  // 생성된 User 객체 반환
    }

    /**
     * Unique ID 생성
     * @param session Hibernate 세션
     * @return 새로운 ID
     */
    public String generateNewId(Session session) {
        CriteriaBuilder cb = session.getCriteriaBuilder();  // CriteriaBuilder 가져오기
        CriteriaQuery<User> cq = cb.createQuery(User.class);  // CriteriaQuery 생성
        Root<User> root = cq.from(User.class);  // Root 객체 생성
        cq.orderBy(cb.desc(root.get("id")));  // ID로 정렬

        TypedQuery<User> query = session.createQuery(cq);  // TypedQuery 생성
        User user = query.setMaxResults(1).getSingleResult();  // 최근 ID 가져오기

        String prefix = "kku_";  // ID 접두사
        int newNumber;

        if (user != null) {  // 기존 User가 있는 경우
            String lastId = user.getId();  // 마지막 ID 가져오기
            int lastNumber = Integer.parseInt(lastId.split("_")[1]);  // 마지막 번호 파싱
            newNumber = lastNumber + 1;  // 새로운 번호 생성
        } else {  // 기존 User가 없는 경우
            newNumber = 1;  // 첫 번째 User의 경우
        }

        return prefix + newNumber;  // 새로운 ID 반환
    }

    @Override
    public List<User> getUsers(User user) {
        List<User> users = null;  // User 목록 초기화

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {  // Hibernate 세션 열기
            CriteriaBuilder cb = session.getCriteriaBuilder();  // CriteriaBuilder 가져오기
            CriteriaQuery<User> criteria = cb.createQuery(User.class);  // CriteriaQuery 생성
            Root<User> root = criteria.from(User.class);  // Root 객체 생성
            Join<User, UserRole> userRolesJoin = root.join("userRoles", JoinType.LEFT);  // UserRole 조인

            criteria.select(root);  // Root 선택
            List<Predicate> conditions = new ArrayList<>();  // 조건 리스트 초기화

            if (user != null) {  // user가 null이 아닌 경우
                if (user.getId() != null && !user.getId().isEmpty()) {
                    conditions.add(cb.like(cb.lower(root.get("id")), "%" + user.getId().toLowerCase() + "%"));  // ID 조건 추가
                }
                if (user.getName() != null && !user.getName().isEmpty()) {
                    conditions.add(cb.like(cb.lower(root.get("name")), "%" + user.getName().toLowerCase() + "%"));  // 이름 조건 추가
                }
                if (user.getEmail() != null && !user.getEmail().isEmpty()) {
                    conditions.add(cb.like(cb.lower(root.get("email")), "%" + user.getEmail().toLowerCase() + "%"));  // 이메일 조건 추가
                }
                if (user.getStatus() != null && !user.getStatus().isEmpty()) {
                    conditions.add(cb.like(cb.lower(root.get("status")), "%" + user.getStatus().toLowerCase() + "%"));  // 상태 조건 추가
                }
                if (user.getUserRoles() != null && user.getUserRoles().size() > 0) {
                    conditions.add(cb.like(cb.lower(userRolesJoin.get("roleName")), "%" + user.getUserRoles().get(0).getRoleName().toLowerCase() + "%"));  // 역할 이름 조건 추가
                }

                // 조건을 Predicate 배열로 변환
                Predicate[] pArr = new Predicate[conditions.size()];
                criteria.where(cb.or(conditions.toArray(pArr)));  // 조건을 CriteriaQuery에 추가
            }

            TypedQuery<User> query = session.createQuery(criteria);  // Query를 TypedQuery로 변경
            users = query.getResultList();  // 결과 목록 가져오기
        } catch (HibernateException e) {  // Hibernate 예외 처리
            e.printStackTrace();  // 예외 발생 시 스택 트레이스 출력
        }

        return users;  // User 목록 반환
    }
}