/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.support.sql;

import org.junit.Test;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class ConnectionPoolUtilTest {

    // testConnection 메서드
    @Test
    public void testConnection() {  // public 으로 수정
        try (Connection connection = ConnectionPoolUtil.getConnection()) {
            // 커넥션 풀 상태 출력
            ConnectionPoolUtil.printConnectionPoolStatus();

            // SQL 실행
            String query = "SELECT * FROM user";
            PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            // 결과 출력
            while (rs.next()) {
                System.out.println("User: " + rs.getString("name"));
            }

            // 커넥션 풀 상태 출력
            ConnectionPoolUtil.printConnectionPoolStatus();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 커넥션 풀 상태 출력 및 종료
            ConnectionPoolUtil.printConnectionPoolStatus();
            ConnectionPoolUtil.closeDataSource();
        }
    }
}