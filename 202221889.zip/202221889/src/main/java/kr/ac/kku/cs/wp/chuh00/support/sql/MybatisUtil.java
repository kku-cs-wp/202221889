/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.support.sql;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources; // 올바른 Resources 클래스 임포트
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class MybatisUtil {
	private static SqlSessionFactory sqlSessionFactory;
	static {
		try {
			// MyBatis 설정 파일 읽기
			String resource = "mybatis-config.xml";
			Reader reader = Resources.getResourceAsReader(resource); // 올바른 Resources 클래스 사용
			// SqlSessionFactoryBuilder를 사용해 SqlSessionFactory 생성
			if (sqlSessionFactory == null) {
				sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static SqlSessionFactory getSqlSessionFactory() {
		return sqlSessionFactory;
	}
}