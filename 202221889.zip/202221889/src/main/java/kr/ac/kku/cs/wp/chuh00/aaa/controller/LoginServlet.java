/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.aaa.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import kr.ac.kku.cs.wp.chuh00.user.controller.User;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

public class LoginServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User sessionUser = (User) session.getAttribute("user");

        if (sessionUser == null) {
            String id = req.getParameter("id");
            String role = req.getParameter("role");

            User user = new User();
            user.setId(id);
            user.setRole(role);

            session.setAttribute("user", user);

            // 로그 기록
            log(user.getId());
            log(user.getRole());

            res.getWriter().println("Login successful.");
        } else {
            res.getWriter().println(sessionUser.getId() + "! Please log out first.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 로그인 처리 로직 구현
        String id = req.getParameter("id");
        String password = req.getParameter("password");

        // ID와 패스워드를 확인 (여기서는 간단하게 ID가 "admin"이고, 패스워드가 "1234"일 때 성공하는 예제)
        if ("admin".equals(id) && "1234".equals(password)) {
            HttpSession session = req.getSession();
            User user = new User();
            user.setId(id);
            user.setRole("admin");
            session.setAttribute("user", user);

            resp.getWriter().println("Login successful. Welcome, " + user.getId() + "!");
        } else {
            req.setAttribute("error", "Invalid login credentials.");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 로그인 페이지로 이동
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }
}