/*
* 저작권 (C) 2024 최우진 202221889 모든 권리 보유.  
*  
* 이 소프트웨어는 고급웹프로그래밍 중간고사 코딩 시험 제출용입니다.  
* 이 소프트웨어는 개인적, 교육적 또는 비상업적 목적으로 자유롭게 사용할 수 있습니다.  
* 상업적 사용을 위해서는 타인의 권리를 침해하지 않도록 주의해야 합니다.  
*  
* 연락처:{ chldnwls37@naver.com }  
*  
*/

package kr.ac.kku.cs.wp.chuh00.user.entity;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;

/**
 * MessageException
 *
 * @author 최우진 2022-21889
 * @since 2024. 10. 24.
 * @version 1.0
 */

@Entity
@Table(name = "user_roles")
public class UserRole {

	@EmbeddedId
	private UserRoleId id;
	@ManyToOne
	@MapsId("userId")
	@JoinColumn(name = "user_id")
	private User user;
	@ManyToOne
	@MapsId("roleId")
	@JoinColumn(name = "role_id")
	private Role role;
	@Column(name = "role", length = 45)
	private String roleName;

	// Constructors–default,fields
	public UserRole() {
	}

	public UserRole(User user, Role role, String roleName) {
		this.user = user;
		this.role = role;
		this.roleName = roleName;
		this.id = new UserRoleId(user.getId(), role.getId());
	}

	public UserRoleId getId() {
		return id;
	}

	public void setId(UserRoleId id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		UserRole userRole = (UserRole) o;

		return Objects.equals(id, userRole.id);
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return Objects.hash(id);
	}

	// 추가 필드 및 getter, setter
}